import { Home, Moon, Sun, Menu } from "lucide-react";
import { Button } from "./ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { motion } from "motion/react";

interface HeaderProps {
  theme: 'light' | 'dark';
  onThemeToggle: () => void;
  onMenuItemClick?: (item: string) => void;
}

const menuItems = [
  "Home",
  "Top-Level",
  "Instance",
  "Themes",
  "Extensions",
  "Upload",
  "Download",
  "Search"
];

export function Header({ theme, onThemeToggle, onMenuItemClick }: HeaderProps) {
  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
      className="bg-background border-b border-border"
    >
      <div className="max-w-6xl mx-auto px-16 py-12">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <h1 className="text-black text-[64px] font-[Inter] font-bold">CardSpoke</h1>
          
          {/* Navigation Buttons */}
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onMenuItemClick?.("Home")}
              className="hover:bg-accent transition-all duration-500 w-11 h-11 text-black rounded-full"
            >
              <Home className="w-5 h-5" strokeWidth={1.5} />
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={onThemeToggle}
              className="hover:bg-accent transition-all duration-500 w-11 h-11 text-black rounded-full"
            >
              {theme === 'light' ? (
                <Moon className="w-5 h-5" strokeWidth={1.5} />
              ) : (
                <Sun className="w-5 h-5" strokeWidth={1.5} />
              )}
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="hover:bg-accent transition-all duration-500 w-11 h-11 text-black rounded-full"
                >
                  <Menu className="w-5 h-5" strokeWidth={1.5} />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 mt-2">
                {menuItems.map((item) => (
                  <DropdownMenuItem
                    key={item}
                    onClick={() => onMenuItemClick?.(item)}
                    className="cursor-pointer py-3 text-sm"
                  >
                    {item}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </motion.header>
  );
}
