import { motion } from "motion/react";

interface InfoCardProps {
  title: string;
  preview: string;
  tags: string[];
  childrenCount: number;
}

export function InfoCard({ title, preview, tags, childrenCount }: InfoCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
      className="cursor-pointer group pb-12 mb-8 rounded-lg p-8 shadow-md hover:shadow-lg transition-shadow duration-500"
    >
      <div className="flex items-start justify-between gap-16">
        {/* Left Content */}
        <div className="flex-1 space-y-4">
          {/* Title */}
          <h3 className="text-black group-hover:opacity-60 transition-opacity duration-500">
            {title}
          </h3>
          
          {/* Preview */}
          <p className="text-muted-foreground max-w-2xl pl-8">
            {preview}
          </p>
          
          {/* Tags */}
          <div className="pl-8 pt-2">
            <p className="text-muted-foreground italic tracking-wide">
              {tags.map((tag, index) => (
                <span key={tag}>
                  #{tag.toLowerCase()}{index < tags.length - 1 && '  '}
                </span>
              ))}
            </p>
          </div>
        </div>
        
        {/* Right Number */}
        {childrenCount > 0 && (
          <div className="text-black flex-shrink-0 opacity-30 group-hover:opacity-50 transition-opacity duration-500">
            <span style={{ 
              fontSize: '80px', 
              fontWeight: 300, 
              lineHeight: 1,
              fontFamily: 'Outfit, sans-serif',
              letterSpacing: '-0.04em'
            }}>
              {childrenCount}
            </span>
          </div>
        )}
      </div>
    </motion.div>
  );
}
