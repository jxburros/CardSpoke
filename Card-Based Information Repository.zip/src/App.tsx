import { useState, useMemo, useEffect } from "react";
import { InfoCard } from "./components/InfoCard";
import { SearchBar } from "./components/SearchBar";
import { Header } from "./components/Header";
import { motion } from "motion/react";
import { toast } from "sonner@2.0.3";
import { Toaster } from "./components/ui/sonner";

interface CardData {
  id: string;
  title: string;
  preview: string;
  tags: string[];
  childrenCount: number;
}

const sampleData: CardData[] = [
  {
    id: "1",
    title: "Design System Foundations",
    preview: "A comprehensive guide to building scalable design systems with consistent patterns, reusable components, and clear documentation.",
    tags: ["Design", "Systems", "Components"],
    childrenCount: 12
  },
  {
    id: "2",
    title: "User Research Methods",
    preview: "Collection of qualitative and quantitative research techniques for understanding user behavior and validating design decisions.",
    tags: ["Research", "UX", "Methodology"],
    childrenCount: 8
  },
  {
    id: "3",
    title: "Typography Guidelines",
    preview: "Principles and best practices for typographic hierarchy, font selection, and creating readable, accessible text layouts.",
    tags: ["Typography", "Design", "Accessibility"],
    childrenCount: 15
  },
  {
    id: "4",
    title: "Interaction Patterns",
    preview: "Common UI patterns and micro-interactions that enhance user experience and provide clear feedback during interactions.",
    tags: ["Interaction", "UX", "Patterns"],
    childrenCount: 23
  },
  {
    id: "5",
    title: "Color Theory & Application",
    preview: "Understanding color psychology, creating harmonious palettes, and applying color strategically in interface design.",
    tags: ["Color", "Design", "Theory"],
    childrenCount: 7
  },
  {
    id: "6",
    title: "Responsive Design Strategies",
    preview: "Techniques for creating fluid layouts that adapt seamlessly across different screen sizes and device capabilities.",
    tags: ["Responsive", "Layout", "Mobile"],
    childrenCount: 11
  },
  {
    id: "7",
    title: "Accessibility Standards",
    preview: "WCAG guidelines, inclusive design principles, and practical approaches to making digital products accessible to all users.",
    tags: ["Accessibility", "WCAG", "Inclusive"],
    childrenCount: 19
  },
  {
    id: "8",
    title: "Animation Principles",
    preview: "Motion design fundamentals, timing functions, and creating purposeful animations that enhance rather than distract.",
    tags: ["Animation", "Motion", "UX"],
    childrenCount: 6
  }
];

export default function App() {
  const [searchQuery, setSearchQuery] = useState("");
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const handleThemeToggle = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  const handleMenuItemClick = (item: string) => {
    toast.message(item, {
      description: `Navigating to ${item}...`
    });
  };

  const filteredCards = useMemo(() => {
    return sampleData.filter(card => {
      const matchesSearch = 
        card.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        card.preview.toLowerCase().includes(searchQuery.toLowerCase()) ||
        card.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
      
      return matchesSearch;
    });
  }, [searchQuery]);

  return (
    <div className="min-h-screen bg-background">
      <Toaster />
      <Header 
        theme={theme}
        onThemeToggle={handleThemeToggle}
        onMenuItemClick={handleMenuItemClick}
      />

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-16 pb-32">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
        >
          {/* Page Title */}
          <h2 className="text-black mb-16 font-normal text-[64px]">Top Level Cards</h2>

          {/* Cards List */}
          {filteredCards.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="py-20"
            >
              <p className="text-muted-foreground">
                No cards found matching your search.
              </p>
            </motion.div>
          ) : (
            <div className="space-y-12">
              {filteredCards.map((card, index) => (
                <motion.div
                  key={card.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.04 }}
                >
                  <InfoCard {...card} />
                </motion.div>
              ))}
            </div>
          )}
          
          {/* Search Bar */}
          <div className="mt-24 pt-12 border-t border-border">
            <SearchBar 
              value={searchQuery} 
              onChange={setSearchQuery}
              placeholder="Search cards, tags, or content..."
            />
          </div>
        </motion.div>
      </main>
    </div>
  );
}
